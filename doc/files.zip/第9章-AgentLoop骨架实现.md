# 第 9 章 · 把一切接起来:Agent Loop 骨架实现

> 第四部分「工程化落地」· 通用概念:把契约装配成循环、编排层代码结构

---

## 本章你会学到

- 前八章的组件怎么拼成一个完整、能跑的 agent
- 编排层(orchestration)的代码结构长什么样
- 工具调用点、状态转移、Working Memory 更新分别放在哪
- 一个统一入口 `diagnose()`,跑通被动问答 MVP

---

## 概念讲解

### 实现只是把设计填空

这一章几乎没有新概念——**如果前八章做对了,这一章会轻松得出乎意料。** 这正是"前期设计"的回报:当契约、状态机、记忆、护栏都已经定死,"实现"就只是把它们按顺序接起来。反过来说,如果这一章让你觉得处处要临时决策、到处打补丁,那说明前面某个设计没做透——**实现阶段的痛苦,是设计阶段偷懒的账单。**

### 编排层的职责

把前面的组件分成两类:

- **能力组件**(各司其职,互不知道彼此):`splunk_client`、`knowledge`、`working_memory`、`evidence_store`、`conclusion`、`guardrails`……
- **编排层**(orchestration):唯一知道"这些组件怎么协作"的地方——它持有状态机,决定何时调哪个组件、按什么顺序、如何在它们之间传数据。

**好的编排层很薄**:它不含业务逻辑(逻辑都在组件里),只含"接线"。这一章写的就是这层薄薄的接线。

### 三个"放哪"问题

装配时你会反复问三个问题,答案是固定的:

1. **工具调用放哪?** 只在 `run_triage` 和 `run_verify` 里,且必穿过 `run_spl`(护栏入口)。
2. **状态转移放哪?** 每个 phase 函数的返回值 + 驱动器的 while 循环。**转移由代码决定,不由模型。**
3. **Working Memory 更新放哪?** 每个 phase 函数内部,拿到结果后立即更新。原始数据进 EvidenceStore,摘要进 WM。

---

## 案例落地:完整项目结构

```
log_agent/
├── knowledge/
│   └── payment-gateway.yaml      # 第3章:领域知识配置
├── eval/
│   └── incidents.yaml            # 第8章:回归集
├── contract.py                   # 第2章:QueryResult
├── splunk_client.py              # 第2章:run_spl(接了护栏)
├── tool_schema.py                # 第2章:给模型看的工具定义
├── knowledge.py                  # 第3章:知识加载
├── prompt_builder.py             # 第3章:system prompt 构建
├── evidence_store.py             # 第5章:外部证据存储
├── working_memory.py             # 第5章:结构化记忆
├── conclusion.py                 # 第6章:输出契约 + 置信度
├── grounding.py                  # 第6章:证据接地校验
├── guardrails.py                 # 第7章:护栏层
├── phases.py                     # 第4/5/6章:四个阶段
└── agent.py                      # 第9章:编排层 + 入口(本章)
```

每个文件都在前面章节写过了。本章只写最后一个:`agent.py`——把它们接起来。

---

## 代码

### phases.py:四个阶段的最终形态(汇总前几章)

先把散在前几章的四个阶段函数,以最终签名汇总(它们内部逻辑已在第 4/5/6 章写过):

```python
# phases.py —— 四个阶段的最终签名(实现见第 4、5、6 章)
from enum import Enum, auto


class Phase(Enum):
    TRIAGE = auto(); HYPOTHESIZE = auto(); VERIFY = auto()
    CONCLUDE = auto(); DONE = auto()


def run_triage(wm, budget) -> Phase: ...        # 第4章:固定SPL,写WM,→HYPOTHESIZE
def run_hypothesize(wm, kb) -> Phase: ...        # 第4章:提假设(不调工具),→VERIFY
def run_verify(wm, store, kb, budget) -> Phase: ...  # 第4/5章:下钻,写WM,判转移
def run_conclude(wm, store, kb):                 # 第6章:结构化结论 + 接地校验
    ...                                          # 返回 Conclusion
```

### agent.py:编排层 + 统一入口

这是全课的收束点。注意它有多"薄"——它只接线,不含任何诊断逻辑:

```python
# agent.py —— 编排层:唯一知道组件如何协作的地方
from dataclasses import dataclass

from knowledge import DomainKnowledge
from working_memory import WorkingMemory
from evidence_store import EvidenceStore
from conclusion import Conclusion
from guardrails import QueryBudget, TerminationGuard, GuardrailViolation
from phases import (
    Phase, run_triage, run_hypothesize, run_verify, run_conclude,
)

KB = DomainKnowledge.load("knowledge/payment-gateway.yaml")   # 第3章


@dataclass
class DiagnoseResult:
    conclusion: Conclusion | None
    message: str
    trace: dict | None = None


def diagnose(
    question: str,
    index: str,
    earliest: str = "-1h",
    latest: str = "now",
    return_trace: bool = False,
) -> DiagnoseResult:
    """被动问答 MVP 的统一入口。工程师问一句,这里跑完整个状态机。"""
    # 1. 初始化每次会话独立的状态
    wm = WorkingMemory(question=question, index=index,
                       earliest=earliest, latest=latest)
    store = EvidenceStore()
    budget = QueryBudget(max_queries=15, max_days=7)
    term = TerminationGuard(max_total_rounds=8)

    phase, rounds, conclusion = Phase.TRIAGE, 0, None

    # 2. 状态机主循环 —— 编排层的核心,也是全部
    while True:
        stop, reason = term.should_terminate(rounds, conclusion)
        if stop:
            break

        rounds += 1
        try:
            if phase == Phase.TRIAGE:
                phase = run_triage(wm, budget)
            elif phase == Phase.HYPOTHESIZE:
                phase = run_hypothesize(wm, KB)
            elif phase == Phase.VERIFY:
                phase = run_verify(wm, store, KB, budget)
            elif phase == Phase.CONCLUDE:
                conclusion = run_conclude(wm, store, KB)
                if conclusion.is_convergent():
                    break
                phase = Phase.HYPOTHESIZE          # 置信度不足,回炉
        except GuardrailViolation as e:
            # 护栏触发:安全收尾,不规避(第7章)
            return DiagnoseResult(
                conclusion=None,
                message=f"因护栏中止:{e}\n当前已知:\n{wm.render()}",
                trace=_trace(wm, store, budget, reason="guardrail") if return_trace else None,
            )

    # 3. 收尾:成功出结论,或诚实报告未收敛
    if conclusion:
        message = _format(conclusion)
    else:
        message = f"查了 {rounds} 轮未能收敛({reason})。\n已排除:{wm.excluded}"

    return DiagnoseResult(
        conclusion=conclusion,
        message=message,
        trace=_trace(wm, store, budget, reason) if return_trace else None,
    )


def _format(c: Conclusion) -> str:
    return (
        f"【根因】{c.root_cause}\n"
        f"【置信度】{c.confidence.value}\n"
        f"【证据】{', '.join(c.evidence_ids)}\n"
        f"【已排除】{', '.join(c.excluded) or '无'}\n"
        f"【建议】{c.suggested_action}"
    )


def _trace(wm, store, budget, reason) -> dict:
    """给第8章评估和第10章可观测性用的运行轨迹。"""
    return {
        "queries_used": budget._used,
        "budget_limit": budget.max_queries,
        "terminated_reason": reason,
        "evidence_store_ids": list(store._store.keys()),
        "side_effect_violations": 0,     # 由护栏保证;第10章会真实记录
        "excluded": wm.excluded,
    }
```

### 跑起来

```python
# run.py —— 被动问答 MVP
from agent import diagnose

if __name__ == "__main__":
    result = diagnose(
        question="昨晚 3 点开始支付大量失败,帮忙看下",
        index="pay_app",
        earliest="-9h",
        latest="-6h",
    )
    print(result.message)
```

就这样。你现在有一个**完整、可控、可信、安全**的日志诊断 agent 了:它会先粗查定位(Triage)、提假设(Hypothesize)、定向下钻(Verify)、给出带证据的结构化结论(Conclude),全程只读、有预算、会收敛。

### 回看:薄编排层的意义

数一下 `diagnose()` 里有多少"诊断逻辑"——几乎没有。它只做三件事:初始化状态、按状态机转移、收尾。所有真正的逻辑(怎么查、怎么判假设、怎么校验证据)都在组件里。**这就是好架构的样子:换个系统,你只改 `knowledge/*.yaml` 和几条 Triage 模板,`agent.py` 一行不动。** 这一点我们在 Capstone 会真正利用起来。

---

## 动手练习

**练习 9.1(通读)**
从 `run.py` 的一次调用出发,在纸上画出完整调用链:`diagnose` → 各 phase → `run_spl` → 护栏 → EvidenceStore → WM → `run_conclude` → 接地校验。标出每一步"数据"和"控制"分别怎么流动。

**练习 9.2(换系统)**
不改 `agent.py`,只新增一份 `knowledge/order-service.yaml` 和对应的 Triage 模板,让这个 agent 能诊断另一个系统。验证"薄编排层"的承诺——业务变化被隔离在配置里。

**练习 9.3(补一个阶段)**
把第 4 章练习设计的 `Correlate` 阶段真正接进 `agent.py`:加进 `Phase` 枚举、写 `run_correlate`、在驱动器里加一个分支。体会"加一个阶段"在这个结构里是多局部的改动。

---

## 本章 Takeaway

> **实现只是把设计填空——前八章做对了,这一章很轻松。** 编排层要薄:它只接线,不含业务逻辑。实现阶段的痛苦,是设计阶段偷懒的账单。

---

## 衔接

agent 能跑了。但"能跑"不等于"能长期养好"。线上它每天做的决策,是你迭代它的金矿——前提是你能看见这些决策。最后一章讲可观测性:怎么让 agent 的每一步决策可追溯,并用真实数据反哺它。

→ 下一章:**第 10 章 · 可观测性与迭代**
